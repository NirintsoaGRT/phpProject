<?php
require 'config.php';
try{
    $pdo=new PDO($db,$user,$password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    
}
catch(PDOException $pe){
 echo "ERREUR :".$pe->getMessage();    
}

?>