<?php
    session_start();
    if($_SESSION["nom"]!=""){
       
        session_destroy();
        header("Location:acceuil.php");
    }
    else{
        header("Location:acceuil.php");
    }
?>