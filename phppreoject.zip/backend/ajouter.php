<?php
    
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> LOGIN FOR ME</h1>
    <div>
        <form action="ajouteTraite.php" method="post">
            
            <label for="name"> name</label>
            <input type="text" id="nom" name="nom">
            <br>
            <label for="mail"> mail</label>
            <input type="text" id="mail" name="mail">
            <br>
            <label for="password"> prenom</label>
            <input type="password" id="password" name="password">
            <br>
            <br>
            <button type="submit">enregistre</button>
            
        </form>
        
    </div>
    
</body>
</html>