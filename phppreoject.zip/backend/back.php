<?php
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> LOGIN FOR ME</h1>
    <div>
        <form action="" methode="get" >     
        <label for="name"> name</label>
            <input type="text" id="nom" name="nom">
            <br>
            <label for="password"> password</label>
            <input type="password" id="password" name="password">
            <br>
            <br>
            <button type="submit">clique moi</button>
            
        </form>
        <a href="ajouter.php">pas de compte</a>
    </div>
</body>
</html>