<?php
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des événements - Interface d'administration</title>
  <link rel="stylesheet" href="tbd.css">
</head>
<body>
  <header>
    <h1>Gestion des événements</h1>
    <nav>
      <ul>
        <li><a href=# class="active">Ajouter un événement</a></li>
        <li><a href=#>Modifier un événement</a></li>
        <li><a href=#>Supprimer un événement</a></li>
        <li><a href="deco.php">Se déconnecter</a></li> <!-- Ajout du lien de déconnexion -->
      </ul>
    </nav>
  </header>
  
  <main>
    <section id="ajouter-event" class="section">
      <h2>Ajouter un événement</h2>
      <form action="add.php" method="post">
        <div class="form-group">
          <label for="titre">Titre:</label>
          <input type="text" id="titre" name="titre" required>
        </div>
        <div class="form-group">
          <label for="description">Description:</label>
          <textarea id="description" name="description" required></textarea>
        </div>
        <div class="form-group">
          <label for="date">Date:</label>
          <input type="date" id="date" name="date" required>
        </div>
        <div class="form-group">
          <label for="heure">Heure:</label>
          <input type="time" id="heure" name="heure" required>
        </div>
        <div class="form-group">
          <label for="image">Image:</label> <!-- Champ pour ajouter une image -->
          <input type="file" id="image" name="image" accept="image/*" required>
        </div>
        <button type="submit">Ajouter</button>
      </form>
    </section>

    <!-- Ajoutez d'autres sections pour modifier et supprimer des événements -->
  </main>

  <footer>
    <p>&copy; 2024 Université Antananarivo</p>
  </footer>
</body>
</html>
