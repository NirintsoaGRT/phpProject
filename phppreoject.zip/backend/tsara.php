
<?php
    session_start();
    include 'pdo.php';
    global $pdo;
    $_SESSION['nom']=$_GET["nom"];
    $_SESSION["password"]=$_GET["password"];
    $nom=$_SESSION["nom"];
    $q=$pdo->query("SELECT * FROM user");
    $c=0;
    while($user=$q->fetch()){
        if($nom ==$user['name'] && $_SESSION['password']==$user['password']){
            $c+=1;
        }
    }
    function verif($c){
        if($c!=0){
            header("Location:connecte.php");
        } 
        else{
            header("Location:acceuil.php");
        }    
    }
    verif($c);  
?>

