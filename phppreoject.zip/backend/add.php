<?php
    session_start();
    $db="mysql:host=localhost;dbname=test";
    $user="aina";
    $password="nirintsoa";
    try{
        $pdo=new PDO($db,$user,$password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        
    }
    catch(PDOException $pe){
     echo "ERREUR :".$pe->getMessage();    
    }
    
    $_SESSION['titre']=$_POST['titre'];
    $_SESSION['description']=$_POST['description'];
    $_SESSION["date"]=$_POST['date'];
    $_SESSION["heur"]=$_POST['heure'];
    $_SESSION["image"]=$_POST['image'];
    $q=$pdo->prepare("INSERT INTO event(titre,description,date,heur,image) VALUE(:titre,:description,:date,:heur,:image)");
    $q->execute([
        'titre' => $_SESSION['titre'],
        'description'=> $_SESSION['description'],
        'date'=> $_SESSION['date'],
        'heur' =>$_SESSION['heur'],
        'image' => $_SESSION['image']
    ]);
    header("Location:connecte.php");

?>