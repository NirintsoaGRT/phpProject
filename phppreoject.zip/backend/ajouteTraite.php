<?php
    session_start();
    include 'pdo.php';
    global $pdo;
    $_SESSION['nom']=$_POST["nom"];
    $_SESSION['mail']=$_POST["mail"];
    $_SESSION["password"]=$_POST["password"];
    $q=$pdo->prepare("INSERT INTO user(name,mail,password) VALUE(:name,:mail,:password)");
    $q->execute([
        'name' => $_SESSION['nom'],
        'mail'=> $_SESSION['mail'],
        'password'=> $_SESSION['password']
    ]);
    header("Location:back.php");
?>
