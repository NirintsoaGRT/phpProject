<?php
  class vehicule{
    protected $marque;
    protected $vites;
    protected $annee;
    public function __construct(string $marque,int $vites,int $ann){
        $this->marque=$marque;
        $this->$vites=$vites;
        $this->annee=$ann;
    }
    public function info(){
        echo $this->marque."<br>";
        echo $this->vites."<br>";
        echo $this->annee."<br>";
    }
  }
  class Moto extends Vehicule
  {
    private $nbtemp;
    public function __construct(string $marque , int $vit,int $ann,string $nbtemp){
        parent::__construct($marque,$vit,$ann);
        $this->nbtemp=$nbtemp;
    }
    public function info(){
        echo $this->marque."<br>";
        echo $this->vites."<br>";
        echo $this->annee."<br>";
        echo $this->nbtemp."<br>";
    }
  }
  $mt= new Moto("jogpro",100,2002,"4t");
  $mt->info();

?>