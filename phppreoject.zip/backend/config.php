<?php

    $db="mysql:host=localhost;dbname=test";
    $user="aina";
    $password="nirintsoa";
?>