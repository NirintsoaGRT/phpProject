<?php
    class Db 
    {
        private $namedb;
        private $nametable;
        private $password;
        
        public function __construct($nombd,$nomtable,$mdp)
        {
            $this->namedb=$nombd;
            $this->nametable=$nomtable;
            $this->password=$mdp;
        }
        public function getName(){
            $m="mysql:host=localhost;dbname=".$this->namedb;
            return $m;

        }
        public function getNametable(){
            return $this->nametable;
        }
        public function getPassword(){
            return $this->password;
        }
    }
  
    
?>