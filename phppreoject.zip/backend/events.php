<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Événements en cours</title>
  <link rel="stylesheet" href="events.css">
</head>
<body>
  <header>
  <nav>
      <ul>
        <li><a href="acceuil.php">Accueil</a></li>
        <li><a href="events.php">Événements</a></li>
    
      </ul>
    </nav>
  </header>
  
  <main>
    <section id="events-list">
      <h2>Événements à venir</h2>
    <?php
        include 'pdo.php';
        global $pdo;
        $q=$pdo->query("SELECT * FROM event");
        while($user=$q->fetch()){

            echo "<div class='event-card'>";
            echo "<img src=".$user['image']."alt='Event 1'>";
            echo "<div class='event-info'>";
            echo "<h3>Événement".$id."</h3>";
            echo"<p>".$user['titre']."</p>";
            echo"<p>".$user['description']."</p>";
            echo "<p>".$user['date']."</p>";
            echo"<p>".$user['heur']."</p>";
            echo "</div>";
         echo "</div>";
        }
      ?>
    </section>
  </main>

  <footer>
    <p>&copy; 2024 Université Antananarivo</p>
  </footer>
</body>
</html>
