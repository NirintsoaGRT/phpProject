<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accueil - Université</title>
  <link rel="stylesheet" href="acceuil.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="acceuil.php">Accueil</a></li>
        <li><a href="events.php">Événements</a></li>
        <li><a href=#>Inscription</a></li>
      </ul>
    </nav>
    <h1>Université Antananarivo</h1>
    <p>Restez informés sur tous les événements du campus!</p>
  </header>
  
  <main>
    <?php
        include 'pdo.php';
        global $pdo;
        $q=$pdo->query("SELECT * FROM event");
        echo"<section class='events'>";
        echo "<h2>Événements à venir</h2>";
        while($user=$q->fetch()){
            if($user['id']<=2){
          
            echo "<div class='event-card'>";
            echo "<img src=".$user['image']."alt='Event 1'>";
            echo "<div class='event-info'>";
            echo "<h3>Événement".$id."</h3>";
            echo"<p>".$user['titre']."</p>";
            echo"<p>".$user['description']."</p>";
            echo "<p>".$user['date']."</p>";
            echo"<p>".$user['heur']."</p>";
            echo "</div>";
         echo "</div>";
            }
        }
    ?>

    <section class="admin-login">
      <h2>Connexion Administrateur</h2>
      <form action="tsara.php" method="get"> 
        <div class="form-group">
          <label for="username">Nom d'utilisateur:</label>
          <input type="text" id="username" name="nom" required>
        </div>
        <div class="form-group">
          <label for="password">Mot de passe:</label>
          <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Se connecter</button>
      </form>
    </section>
  </main>

  <footer>
    <!-- Ajoutez des informations de pied de page ici -->
  </footer>
</body>
</html>

